package Fizzbuzz;

public class FizzBuzz {
    public static String calculate(Integer input){
    
        // Your Code goes here :)
    
        return input.toString();
    }
}