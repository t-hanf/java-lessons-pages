package Fizzbuzz;
import java.util.Scanner;

public class Main {
    public static void main(String argv[]){
        System.out.println("Please enter a number: ");
        Scanner input = new Scanner(System.in);
        System.out.println(FizzBuzz.calculate(input.nextInt()));
    }
}
