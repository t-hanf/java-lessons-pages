public class Teacher extends Person {
    private int currentSalary;
    private Course[] courses;
    private int courseCount;

    public Teacher(String name, int yearOfBirth) {
        super(name, yearOfBirth);
        courseCount = 0;
        courses = new Course[10];
    }

    public void setSalary(int newSalary) {
        this.currentSalary = newSalary;
    }

    public int getSalary() {
        return currentSalary;
    }

    public boolean addCourse(Course newCourse) {
        if (courseCount < 10) {
            courses[courseCount] = newCourse;
            courseCount++;
            newCourse.setTeacher(this);
            return true;
        }
        return false;
    }

    public Course[] getCourses() {
        return courses;
    }

    public String toString() {
        return String.format("Teacher\n%s\nCourses: %s\n", super.toString(), getCourseListString());
    }

    private String getCourseListString() {
        String result = "";
        for (int i = 0; i < courseCount; i++) {
            result += "- " + courses[i].getName() + "\n";
        }
        return result;
    }
}
