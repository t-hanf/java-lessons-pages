public class UniversityResourcePlanner {
    public static void main(String[] args) {
        Student[] students = new Student[5];

        Student student1 = new Student("Time", 1990);
        student1.setDegree("Bachelor Computer Science");
        student1.setEnrolmentNumber(1234);

        students[0] = student1;


        Course EMI = new Course("Einführung in die Medieninformatik");
        Teacher teacher1 = new Teacher("Prof. Weber", 1960);
        teacher1.addCourse(EMI);
        EMI.enrollStudent(student1);

        System.out.println(EMI);
        System.out.println(teacher1);
        System.out.println(student1);
    }

    static void currentDegree(Student[] students, String degree) {

        int h = 0;
        while (h < students.length) {
            if (students[h].getDegree() == degree) {
                System.out.println(students[h].getName());
            }
            h++;
        }

    }

    static Student getBestStudent(Student[] students) {

        Student currentBestStudent = null;
        // float currentBestAvgMark = Float.MAX_VALUE;

        for (int i = 0; i < students.length; i++) {
            if (currentBestStudent == null || students[i].getAverageMark() < currentBestStudent.getAverageMark()) {
                // currentBestAvgMark = students[i].getAverageMark();
                currentBestStudent = students[i];
            }
        }

        return currentBestStudent;
    }
}