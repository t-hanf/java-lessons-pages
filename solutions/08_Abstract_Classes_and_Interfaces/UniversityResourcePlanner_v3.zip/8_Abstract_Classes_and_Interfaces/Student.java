public class Student extends Person {
    private String name;
    private int yearOfBirth;
    private int enrolNumber;
    private String degree;
    private Gradeable[] gradeables = new Gradeable[10];
    private int currentMarkIndex = 0;

    public Student(String name, int yearOfBirth) {
        super(name, yearOfBirth);
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getDegree() {
        return degree;
    }

    public void setEnrolmentNumber(int enrolNumber) {
        this.enrolNumber = enrolNumber;
    }

    public int getEnrolNumber() {
        return enrolNumber;
    }

    public boolean addGradeable(Gradeable gradeable) {
        // iterates over the marks array and adds the mark to the first empty position

        if (currentMarkIndex >= gradeables.length)
            return false;

        gradeables[currentMarkIndex] = gradeable;
        currentMarkIndex++;

        return true;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public int getAge(int year) {
        // returns the age of the student
        return year - yearOfBirth;
    }

    public Gradeable getGradeable(int index) {
        // returns the mark at the given index
        if (index < 0 || index >= currentMarkIndex)
            return null;
        else
            return gradeables[index];
    }

    public float getAverageMark() {

        float sum = 0;
        if (currentMarkIndex == 0)
            return .0f;

        for (int i = 0; i < currentMarkIndex; i++) {
            sum += gradeables[i].calculateGrade();
        }

        return sum / currentMarkIndex;
    }

    @Override
    public String toString() {
        return String.format("Student\n ", super.toString());
    }
}