public class Exam implements Gradeable{
    private int reachedPoints;
    private int totalPoints;

    public Exam(int reachedPoints, int totalPoints) {
        this.reachedPoints = reachedPoints;
        this.totalPoints = totalPoints;
    }

    public int getReachedPoints() {
        return reachedPoints;
    }

    public void setReachedPoints(int reachedPoints) {
        this.reachedPoints = reachedPoints;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }

    @Override
    public float calculateGrade() {
        float percentage = reachedPoints / totalPoints;

        // Create a variable for storing the grade
        float grade;

        // Decide the grade based on the table
        if (percentage >= .93f) {
            grade = 1.0f;
        } else if (percentage >= .88f) {
            grade = 1.3f;
        } else if (percentage >= .81f) {
            grade = 1.7f;
        } else if (percentage >= .76f) {
            grade = 2.0f;
        } else if (percentage >= .71f) {
            grade = 2.3f;
        } else if (percentage >= .64f) {
            grade = 2.7f;
        } else if (percentage >= .59f) {
            grade = 3.0f;
        } else if (percentage >= .54f) {
            grade = 3.3f;
        } else if (percentage >= .47f) {
            grade = 3.7f;
        } else if (percentage >= .42f) {
            grade = 4.0f;
        } else {
            grade = 5.0f;
        }

        return grade;
    }
}