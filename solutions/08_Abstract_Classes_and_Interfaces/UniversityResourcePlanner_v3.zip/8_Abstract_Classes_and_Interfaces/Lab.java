public class Lab implements Gradeable {
    private float[] grades = new float[10];
    private int currentMarkIndex = 0;

    public float[] getGrades() {
        return grades;
    }

    public void setGrades(float[] grades) {
        this.grades = grades;
    }

    public boolean addMark(float mark) {
        // iterates over the marks array and adds the mark to the first empty position

        if (currentMarkIndex >= grades.length)
            return false;

        grades[currentMarkIndex] = mark;
        currentMarkIndex++;

        return true;
    }

    @Override
    public float calculateGrade() {
        float sum = 0;
        if (currentMarkIndex == 0)
            return .0f;

        for (int i = 0; i < currentMarkIndex; i++) {
            sum += grades[i];
        }

        return sum / currentMarkIndex;
    }
}
