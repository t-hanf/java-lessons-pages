public class Thesis implements Gradeable {
    private float gradeTeacher1;
    private float gradeTeacher2;
    private float gradeTeacher3;

    public Thesis(float gradeTeacher1, float gradeTeacher2, float gradeTeacher3) {
        this.gradeTeacher1 = gradeTeacher1;
        this.gradeTeacher2 = gradeTeacher2;
        this.gradeTeacher3 = gradeTeacher3;
    }

    public float getGradeTeacher1() {
        return gradeTeacher1;
    }

    public void setGradeTeacher1(float gradeTeacher1) {
        this.gradeTeacher1 = gradeTeacher1;
    }

    public float getGradeTeacher2() {
        return gradeTeacher2;
    }

    public void setGradeTeacher2(float gradeTeacher2) {
        this.gradeTeacher2 = gradeTeacher2;
    }

    public float getGradeTeacher3() {
        return gradeTeacher3;
    }

    public void setGradeTeacher3(float gradeTeacher3) {
        this.gradeTeacher3 = gradeTeacher3;
    }

    @Override
    public float calculateGrade() {
        return (gradeTeacher1 + gradeTeacher2 + gradeTeacher3) / 3;
    }
}
