public interface Gradeable{
    public float calculateGrade();
}
