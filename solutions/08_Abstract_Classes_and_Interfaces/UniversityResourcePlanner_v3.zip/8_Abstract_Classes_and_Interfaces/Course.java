public class Course {
    private String name;
    private Teacher teacher;
    private Student[] students;
    private int numberOfStudents;

    public Course(String name){
        this.name = name;
        numberOfStudents = 0;
        students = new Student[10];
    }

    public String getName(){
        return name;
    }

    public boolean enrollStudent(Student student){
        if (numberOfStudents < 10) {
            students[numberOfStudents] = student;
            numberOfStudents++;
            return true;
        } 

        return false;
    }

    public Student[] getStudents(){
        return students;
    }

    public Teacher getTeacher(){
        return teacher;
    }

    public void setTeacher(Teacher teacher){
        this.teacher = teacher;
    }

    public String toString(){
        return String.format("Course name: %s\nTeacher: %s\nStudents: %s", name, teacher.getName(), getStudentListString());
    }

    private String getStudentListString(){
        String result = "";
        for (int i = 0; i < numberOfStudents; i++) {
            result += "- " + students[i].getName() + "\n";
        }
        return result;
    }
}
