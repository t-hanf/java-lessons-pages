package Fizzbuzz;

// Import the Scanner
import java.util.Scanner;

public class Main {
    public static void main(String argv[]) {
        System.out.println("Please enter a number: ");

        // Create a scanner
        Scanner input = new Scanner(System.in);

        // Call the FizzBuzz implementation with an integer
        // from the input
        System.out.println(FizzBuzz.calculate(input.nextInt()));

        // Close the input
        input.close();
    }
}