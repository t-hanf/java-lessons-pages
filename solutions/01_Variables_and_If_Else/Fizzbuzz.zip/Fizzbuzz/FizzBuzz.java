package Fizzbuzz;

public class FizzBuzz {
    public static String calculate(Integer input) {

        // If i divisible by 3
        if ((input % 3) == 0) {

            // and i divisible by 5
            if ((input % 5) == 0) {

                // Result is FizzBuzz
                return "fizzbuzz";
            }

            // Result if Fizz
            return "fizz";
        }

        // If i divisible by 5
        else if ((input % 5) == 0) {
            // Result if Buzz
            return "buzz";
        }

        // If i is not divisible by 3 or 5
        else {
            // Result is just the number
            return input.toString();
        }
    }
}